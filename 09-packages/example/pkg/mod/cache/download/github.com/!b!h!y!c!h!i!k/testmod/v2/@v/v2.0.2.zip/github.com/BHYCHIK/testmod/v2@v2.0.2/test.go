package testmod

import (
    "fmt"
)

func Hello(name string, surname string) {
    fmt.Printf("Hello %s %s\n", name, surname)
}
